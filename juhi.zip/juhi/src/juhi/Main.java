package juhi;
import java.lang.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
public class Main{
	
	
	 
	 public static void main(String args[]){
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("Enter number of books borrowed");
		 int a=sc.nextInt();
		 if(a>3){
			 System.out.println("No books can be further borrowed");
		 }
		 else{
			 if(a>=0&&a<3){
				 System.out.println("number of more books you can borrow is "+(3-a));
			 }
		 }
		 System.out.println("Enter the date of borrowing in date format i.e YYYY-MM-DD");
		 sc.nextLine();
		 String oldDate= sc.nextLine();
		 System.out.println("Date before Borrowing: "+oldDate);
		 SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
		 Calendar c = Calendar.getInstance();
		 try{
	   
	   c.setTime(sd.parse(oldDate));
	}catch(ParseException e){
		e.printStackTrace();
	 }
	
	c.add(Calendar.DAY_OF_MONTH, 14);  
	
	String newDate = sd.format(c.getTime());  

	System.out.println("Return date: "+newDate);
	System.out.println("enter number of days which the book has been borrowed");
	int b= sc.nextInt();
	if(b>14){
		System.out.println("overdue");
	}
	else{
		if(b<=14&&b>0)
		{
			System.out.println("Borrowed");
		}	
		else{
			System.out.println("Available");
		}
		}
	
	

	 
		  
			 
		 
		 
		 
		 
		 
		 
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
 }
